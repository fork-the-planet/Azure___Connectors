# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

# pylint: disable=too-many-lines
# pylint: disable=too-many-statements


def load_command_table(self, _):  # pylint: disable=unused-argument
    # Import the custom-overlay module so its ``@register_command`` decorators
    # run at this point in the loader lifecycle and replace any
    # aaz-generated registrations with the same command names. The aaz tree
    # has already been registered by ``load_aaz_command_table`` (see the
    # extension's ``__init__.py``) at this stage, so any recipe imported
    # here wins.
    from . import custom  # noqa: F401  pylint: disable=unused-import,import-outside-toplevel
