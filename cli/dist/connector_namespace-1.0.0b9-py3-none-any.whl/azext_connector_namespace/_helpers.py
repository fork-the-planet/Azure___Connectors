# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

# pylint: disable=too-many-lines
# pylint: disable=too-many-statements
# pylint: disable=line-too-long

"""Pure helpers shared by ``custom.py`` and unit tests.

Everything in this module is intentionally framework-free: no imports
from ``azure.cli.core``, ``azure.cli.core.aaz``, or the generated
``aaz/`` tree. That keeps the helpers fast to import and trivially
unit-testable without pulling in the full Azure CLI stack.
"""

import copy
from typing import Any, Dict, Iterable, Mapping, Optional


# CLI <-> service enum mapping for McpServerConfigProperties.authenticationMode.
# ``NotSpecified`` exists in the service enum but is never surfaced to users -
# omitting ``--authentication-mode`` keeps the service default
# (``DeveloperConnection`` behavior).
AUTHENTICATION_MODE_MAP: Dict[str, str] = {
    "developer-connection": "DeveloperConnection",
    "on-behalf-of-user": "OnBehalfOfUser",
    "on-behalf-of-user-with-app": "OnBehalfOfUserWithApp",
    "app-only": "AppOnly",
}
AUTHENTICATION_MODE_VALUES = tuple(AUTHENTICATION_MODE_MAP.keys())

# CLI <-> service enum mapping for McpServerConfigDefinition.kind.
KIND_MAP: Dict[str, str] = {
    "managed-mcp-server": "ManagedMcpServer",
    "hosted-mcp-server": "HostedMcpServer",
}
KIND_VALUES = tuple(KIND_MAP.keys())

# Authentication modes that require a ``resourceAuth`` payload server-side.
AUTHENTICATION_MODES_REQUIRING_RESOURCE_AUTH = frozenset(
    {"OnBehalfOfUserWithApp", "AppOnly"}
)

# Fields stripped from a GET payload before sending it back as a PUT body.
_READ_ONLY_RESOURCE_FIELDS = ("id", "name", "type", "systemData", "etag")


def map_authentication_mode(cli_value: Optional[str]) -> Optional[str]:
    """Translate a CLI ``--authentication-mode`` value to the service enum
    value, or ``None`` when the CLI value is missing.

    Raises :class:`ValueError` for an unknown value so the CLI surfaces a
    clear error before sending the request.
    """
    if cli_value is None or cli_value == "":
        return None
    try:
        return AUTHENTICATION_MODE_MAP[cli_value]
    except KeyError as exc:
        raise ValueError(
            f"Unknown authentication-mode value '{cli_value}'. Expected one of "
            f"{sorted(AUTHENTICATION_MODE_MAP)}."
        ) from exc


def map_kind(cli_value: Optional[str]) -> Optional[str]:
    """Translate a CLI ``--kind`` value to the service enum, or ``None``
    when the CLI value is missing.
    """
    if cli_value is None or cli_value == "":
        return None
    try:
        return KIND_MAP[cli_value]
    except KeyError as exc:
        raise ValueError(
            f"Unknown kind value '{cli_value}'. Expected one of "
            f"{sorted(KIND_MAP)}."
        ) from exc


def is_obo_authentication_mode(service_value: Optional[str]) -> bool:
    """Return ``True`` when ``service_value`` is one of the OBO modes
    (``OnBehalfOfUser`` or ``OnBehalfOfUserWithApp``)."""
    return service_value in {"OnBehalfOfUser", "OnBehalfOfUserWithApp"}


def requires_resource_auth(service_value: Optional[str]) -> bool:
    """Return ``True`` when ``service_value`` is a mode that requires the
    server-side ``resourceAuth`` payload to be present."""
    return service_value in AUTHENTICATION_MODES_REQUIRING_RESOURCE_AUTH


def strip_read_only_fields(resource: Mapping[str, Any]) -> Dict[str, Any]:
    """Return a deep copy of ``resource`` with read-only fields removed.

    PUT requests must not include ``id``, ``name``, ``type``, ``systemData``,
    or ``etag``; the service rejects bodies that try to set them.
    """
    body = copy.deepcopy(dict(resource))
    for ro in _READ_ONLY_RESOURCE_FIELDS:
        body.pop(ro, None)
    return body


def build_namespace_tag_update_body(
    existing: Mapping[str, Any],
    new_tags: Optional[Mapping[str, str]],
) -> Dict[str, Any]:
    """Build a PUT body for a tag-only namespace update.

    ``az connector-namespace update --tags`` is implemented as a
    read-modify-write: read the resource, replace the ``tags`` map (or leave
    it unchanged if ``new_tags`` is ``None``), and PUT the full resource back.

    Read-only envelope fields are stripped from the body. ``location``,
    ``identity``, ``properties``, and ``kind`` are preserved unchanged.
    """
    body = strip_read_only_fields(existing)
    if new_tags is not None:
        body["tags"] = dict(new_tags)
    return body


def parse_tags(values: Optional[Iterable[str]]) -> Optional[Dict[str, str]]:
    """Parse a sequence of ``key=value`` tokens into a tag map.

    Returns ``None`` when ``values`` is ``None`` (i.e. ``--tags`` was not
    passed). Returns an empty dict when the user explicitly passed ``--tags
    ""`` (token list is empty) to clear all tags.

    Tokens without ``=`` are interpreted as a key with an empty value, which
    matches the Azure CLI ``arg_type=tags_type`` convention.
    """
    if values is None:
        return None
    result: Dict[str, str] = {}
    for token in values:
        if not token:
            continue
        if "=" in token:
            key, _, value = token.partition("=")
            result[key.strip()] = value
        else:
            result[token.strip()] = ""
    return result
