# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

# pylint: disable=too-many-lines
# pylint: disable=too-many-statements
# pylint: disable=line-too-long
# pylint: disable=logging-fstring-interpolation
# pylint: disable=broad-exception-caught
# pylint: disable=too-few-public-methods
# pylint: disable=import-error
# pylint: disable=protected-access
# Accessing _help and _registered on aaz-generated AAZArg objects is
# the documented escape hatch for hiding/tightening args in subclassed
# commands. There is no public setter today.

"""Custom command overlays for the connector-namespace extension.

The aaz-generated tree provides full CRUD for every Connector Namespace
resource. This module layers a single recipe on top of that tree:

1. ``az connector-namespace update`` is reduced to a **tag-only** patch.
   Aaz's auto-generated Update exposes ``--api-hub-environment-id`` plus
   the generic-update flags (``--set``/``--add``/``--remove``/
   ``--force-string``) on top of ``--tags``. This subclass hides every
   non-tag argument, disables generic-update, and tightens ``--tags``
   help.

Recipes are wired by importing this module from
:func:`load_command_table` in ``commands.py``. The
``@register_command`` decorator on the subclass below replaces the
aaz-generated registration at import time.
"""

from knack.log import get_logger

from azure.cli.core.aaz import has_value, register_command

from .aaz.latest.connector_namespace import Update as _NamespaceUpdate


logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Recipe 1: tag-only update for the connector namespace.
# ---------------------------------------------------------------------------


# Schema args that ARE allowed on the tag-only update. Anything else found
# on the parent's schema is force-hidden at build time so a regenerated aaz
# tree can't silently re-introduce a non-tag body arg behind our backs.
_ALLOWED_UPDATE_ARGS = frozenset({
    "connector_namespace_name",
    "resource_group",
    "tags",
})


@register_command(
    "connector-namespace update",
)
class TagOnlyNamespaceUpdate(_NamespaceUpdate):
    """Update the tags on a connector namespace.

    Tags are the only mutable field exposed by this command. The aaz
    generic-update machinery (``--set``/``--add``/``--remove``/
    ``--force-string``) is disabled so callers cannot reach around the
    whitelist via JMESPath directives.
    """

    # Disable aaz's generic update support so --set/--add/--remove are not
    # registered. The parent's value is True.
    AZ_SUPPORT_GENERIC_UPDATE = False

    @classmethod
    def _build_arguments_schema(cls, *args, **kwargs):
        schema = super()._build_arguments_schema(*args, **kwargs)

        # Tighten the --tags help so the contract is unambiguous.
        tags_arg = getattr(schema, "tags", None)
        if tags_arg is not None and hasattr(tags_arg, "_help") and isinstance(tags_arg._help, dict):
            tags_arg._help["short-summary"] = (
                "Resource tags as space-separated key=value pairs. Pass an "
                "empty string to clear all tags. Tags are the only mutable "
                "field exposed by this command."
            )

        # Whitelist enforcement: hide anything the parent registered that
        # isn't in ALLOWED_UPDATE_ARGS. Walking the schema's discovered
        # field set means a regen that adds a new arg is automatically
        # caught without an extra edit here.
        for arg_name in list(schema._fields):
            if arg_name in _ALLOWED_UPDATE_ARGS:
                continue
            arg = getattr(schema, arg_name, None)
            if arg is not None and hasattr(arg, "_registered"):
                arg._registered = False

        return schema

    def pre_operations(self):  # pragma: no cover - exercised by ScenarioTest
        cli_args = self.ctx.args
        if not has_value(cli_args.tags):
            logger.warning(
                "No --tags supplied; nothing to update. "
                "Pass --tags key=value to set tags, or --tags '' to clear."
            )
        return super().pre_operations()


__all__ = ["TagOnlyNamespaceUpdate"]
