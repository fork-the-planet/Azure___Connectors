# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

"""Unit tests for ``azext_connector_namespace._helpers``.

The helper module is intentionally framework-free, so these tests don't
touch ``azure.cli.core`` or the generated aaz tree. They run on a fresh
checkout without azdev/aaz-dev being installed.
"""

import unittest

from azext_connector_namespace._helpers import (
    AUTHENTICATION_MODE_MAP,
    AUTHENTICATION_MODE_VALUES,
    AUTHENTICATION_MODES_REQUIRING_RESOURCE_AUTH,
    KIND_MAP,
    KIND_VALUES,
    build_namespace_tag_update_body,
    is_obo_authentication_mode,
    map_authentication_mode,
    map_kind,
    parse_tags,
    requires_resource_auth,
    strip_read_only_fields,
)


class TestAuthenticationModeMap(unittest.TestCase):
    def test_all_cli_values_listed(self):
        self.assertEqual(
            set(AUTHENTICATION_MODE_VALUES),
            {
                "developer-connection",
                "on-behalf-of-user",
                "on-behalf-of-user-with-app",
                "app-only",
            },
        )

    def test_map_to_service_value(self):
        self.assertEqual(
            map_authentication_mode("developer-connection"), "DeveloperConnection"
        )
        self.assertEqual(map_authentication_mode("on-behalf-of-user"), "OnBehalfOfUser")
        self.assertEqual(
            map_authentication_mode("on-behalf-of-user-with-app"), "OnBehalfOfUserWithApp"
        )
        self.assertEqual(map_authentication_mode("app-only"), "AppOnly")

    def test_none_and_empty_pass_through(self):
        self.assertIsNone(map_authentication_mode(None))
        self.assertIsNone(map_authentication_mode(""))

    def test_unknown_value_raises(self):
        with self.assertRaises(ValueError):
            map_authentication_mode("totally-invalid")

    def test_obo_detection(self):
        self.assertTrue(is_obo_authentication_mode("OnBehalfOfUser"))
        self.assertTrue(is_obo_authentication_mode("OnBehalfOfUserWithApp"))
        self.assertFalse(is_obo_authentication_mode("DeveloperConnection"))
        self.assertFalse(is_obo_authentication_mode("AppOnly"))
        self.assertFalse(is_obo_authentication_mode(None))

    def test_resource_auth_required(self):
        self.assertTrue(requires_resource_auth("OnBehalfOfUserWithApp"))
        self.assertTrue(requires_resource_auth("AppOnly"))
        self.assertFalse(requires_resource_auth("DeveloperConnection"))
        self.assertFalse(requires_resource_auth("OnBehalfOfUser"))
        self.assertFalse(requires_resource_auth(None))


class TestKindMap(unittest.TestCase):
    def test_values(self):
        self.assertEqual(
            set(KIND_VALUES), {"managed-mcp-server", "hosted-mcp-server"}
        )

    def test_map(self):
        self.assertEqual(map_kind("managed-mcp-server"), "ManagedMcpServer")
        self.assertEqual(map_kind("hosted-mcp-server"), "HostedMcpServer")

    def test_none_and_empty_pass_through(self):
        self.assertIsNone(map_kind(None))
        self.assertIsNone(map_kind(""))

    def test_unknown_raises(self):
        with self.assertRaises(ValueError):
            map_kind("garbage")


class TestStripReadOnlyFields(unittest.TestCase):
    def test_removes_read_only(self):
        body = strip_read_only_fields(
            {
                "id": "/subscriptions/x",
                "name": "g1",
                "type": "Microsoft.Web/connectorGateways",
                "systemData": {"createdBy": "u"},
                "etag": '"abc"',
                "location": "westus",
                "properties": {"foo": "bar"},
            }
        )
        self.assertNotIn("id", body)
        self.assertNotIn("name", body)
        self.assertNotIn("type", body)
        self.assertNotIn("systemData", body)
        self.assertNotIn("etag", body)
        self.assertEqual(body["location"], "westus")
        self.assertEqual(body["properties"], {"foo": "bar"})

    def test_deep_copy_isolated(self):
        original = {"properties": {"inner": {"value": 1}}}
        body = strip_read_only_fields(original)
        body["properties"]["inner"]["value"] = 99
        # Mutation must not leak back to the original.
        self.assertEqual(original["properties"]["inner"]["value"], 1)


class TestBuildNamespaceTagUpdateBody(unittest.TestCase):
    def _sample(self):
        return {
            "id": "/subscriptions/x/.../connectorGateways/g1",
            "name": "g1",
            "type": "Microsoft.Web/connectorGateways",
            "systemData": {"createdBy": "u"},
            "location": "westus",
            "tags": {"env": "dev"},
            "properties": {"prop1": "value1"},
            "identity": {"type": "SystemAssigned"},
        }

    def test_replaces_tags(self):
        body = build_namespace_tag_update_body(
            self._sample(), {"env": "prod", "team": "ai"}
        )
        self.assertEqual(body["tags"], {"env": "prod", "team": "ai"})
        # Envelope preserved.
        self.assertEqual(body["location"], "westus")
        self.assertEqual(body["properties"], {"prop1": "value1"})
        self.assertEqual(body["identity"], {"type": "SystemAssigned"})

    def test_clear_tags(self):
        body = build_namespace_tag_update_body(self._sample(), {})
        self.assertEqual(body["tags"], {})

    def test_none_preserves_existing_tags(self):
        body = build_namespace_tag_update_body(self._sample(), None)
        self.assertEqual(body["tags"], {"env": "dev"})

    def test_strips_read_only(self):
        body = build_namespace_tag_update_body(self._sample(), {"x": "y"})
        for ro in ("id", "name", "type", "systemData", "etag"):
            self.assertNotIn(ro, body)


class TestParseTags(unittest.TestCase):
    def test_none_returns_none(self):
        self.assertIsNone(parse_tags(None))

    def test_empty_returns_empty_dict(self):
        self.assertEqual(parse_tags([]), {})

    def test_key_value_pairs(self):
        self.assertEqual(
            parse_tags(["env=prod", "team=ai"]),
            {"env": "prod", "team": "ai"},
        )

    def test_key_without_value(self):
        self.assertEqual(parse_tags(["bareKey"]), {"bareKey": ""})

    def test_empty_value(self):
        self.assertEqual(parse_tags(["env="]), {"env": ""})

    def test_value_with_equals_sign(self):
        self.assertEqual(parse_tags(["query=a=b"]), {"query": "a=b"})

    def test_skips_empty_tokens(self):
        self.assertEqual(
            parse_tags(["", "env=prod", ""]),
            {"env": "prod"},
        )


class TestRecipeOverlay(unittest.TestCase):
    """Test the TagOnlyNamespaceUpdate recipe contract.

    These run pure-Python against the aaz class (no Azure calls). They
    catch regressions where a swagger update + regen would silently
    re-expose body fields that the recipe is meant to hide.
    """

    def test_module_import(self):
        from azext_connector_namespace import custom  # noqa: WPS433
        self.assertTrue(hasattr(custom, "TagOnlyNamespaceUpdate"))

    def test_overlay_subclasses_aaz_update(self):
        from azext_connector_namespace import custom  # noqa: WPS433
        from azext_connector_namespace.aaz.latest.connector_namespace import (
            Update as _AazUpdate,
        )
        self.assertTrue(issubclass(custom.TagOnlyNamespaceUpdate, _AazUpdate))

    def test_generic_update_disabled(self):
        """``--set/--add/--remove/--force-string`` must not be registered."""
        from azext_connector_namespace.custom import TagOnlyNamespaceUpdate
        self.assertFalse(TagOnlyNamespaceUpdate.AZ_SUPPORT_GENERIC_UPDATE)
        schema = TagOnlyNamespaceUpdate._build_arguments_schema()
        for forbidden in (
            "generic_update_add",
            "generic_update_set",
            "generic_update_remove",
            "generic_update_force_string",
        ):
            self.assertNotIn(
                forbidden,
                list(schema._fields),
                f"{forbidden} leaked back onto the recipe schema",
            )

    def test_only_tags_is_a_registered_body_arg(self):
        """Routing args + --tags are registered; any other body arg is hidden.

        The whitelist is intentionally tight: a regen that adds a new
        property-shaped arg must be force-hidden so the recipe's
        "tag-only" contract doesn't silently regress.
        """
        from azext_connector_namespace.custom import TagOnlyNamespaceUpdate
        _ALLOWED = {"connector_namespace_name", "resource_group", "tags"}
        schema = TagOnlyNamespaceUpdate._build_arguments_schema()
        for arg_name in list(schema._fields):
            arg = getattr(schema, arg_name, None)
            registered = getattr(arg, "_registered", True)
            if arg_name in _ALLOWED:
                self.assertTrue(
                    registered,
                    f"{arg_name} must remain registered (in allow-list)",
                )
            else:
                self.assertFalse(
                    registered,
                    f"{arg_name} must be hidden (not in allow-list)",
                )

    def test_api_hub_environment_id_specifically_hidden(self):
        """Explicit regression for the bug the review caught: the prior
        denylist had nothing in common with the actual schema, so
        --api-hub-environment-id leaked through."""
        from azext_connector_namespace.custom import TagOnlyNamespaceUpdate
        schema = TagOnlyNamespaceUpdate._build_arguments_schema()
        arg = getattr(schema, "api_hub_environment_id", None)
        self.assertIsNotNone(
            arg,
            "api_hub_environment_id no longer exists on the aaz schema; "
            "delete this test (or update _ALLOWED if newly allowed).",
        )
        self.assertFalse(
            getattr(arg, "_registered", True),
            "api_hub_environment_id must be hidden on the tag-only recipe",
        )

    def test_tags_help_tightened(self):
        from azext_connector_namespace.custom import TagOnlyNamespaceUpdate
        schema = TagOnlyNamespaceUpdate._build_arguments_schema()
        summary = schema.tags._help.get("short-summary", "")
        self.assertIn("Tags are the only mutable field", summary)


if __name__ == "__main__":
    unittest.main()
