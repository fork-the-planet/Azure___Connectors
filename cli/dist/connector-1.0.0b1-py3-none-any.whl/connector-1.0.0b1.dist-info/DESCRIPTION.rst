# Azure CLI Connector Extension



Manage **`Microsoft.Web/connectorGateways`** Connector Namespaces and their

children — API Connections, MCP Connectors, Triggers, and Entra ID access

policies — from the Azure CLI.



> ⚠️ This extension is in **preview**. Command names, arguments, and

> behaviors may change before GA.



---



## Contents



- [Install / upgrade / uninstall](#install--upgrade--uninstall)

- [Concepts](#concepts)

- [Quick reference](#quick-reference)

- [Cookbook recipes](#cookbook-recipes)

  - [Recipe 1 — Bootstrap: namespace + connection + MCP connector](#recipe-1--bootstrap-namespace--connection--mcp-connector)

  - [Recipe 2 — OAuth consent flow for a connection](#recipe-2--oauth-consent-flow-for-a-connection)

  - [Recipe 3 — Grant a teammate access to a connection](#recipe-3--grant-a-teammate-access-to-a-connection)

  - [Recipe 4 — Grant a teammate access to an MCP connector](#recipe-4--grant-a-teammate-access-to-an-mcp-connector)

  - [Recipe 5 — On-behalf-of-user (OBO) MCP connector](#recipe-5--on-behalf-of-user-obo-mcp-connector)

  - [Recipe 6 — Hosted MCP server (FIC + admin app registration)](#recipe-6--hosted-mcp-server-fic--admin-app-registration)

  - [Recipe 7 — Invoke a connector operation through the gateway](#recipe-7--invoke-a-connector-operation-through-the-gateway)

  - [Recipe 8 — Webhook trigger on new email](#recipe-8--webhook-trigger-on-new-email)

  - [Recipe 9 — Mint a runtime API key for clients](#recipe-9--mint-a-runtime-api-key-for-clients)

  - [Recipe 10 — Browse the managed catalogs](#recipe-10--browse-the-managed-catalogs)

- [API keys vs. access keys](#api-keys-vs-access-keys)

- [`--namespace` alias on every command](#--namespace-alias-on-every-command)

- [Troubleshooting](#troubleshooting)



---



## Install / upgrade / uninstall



```bash

# Install (preview build distributed as a .whl)

az extension add --source <path-to>/connector-1.0.0b1-py3-none-any.whl



# Upgrade in place

az extension add --upgrade --source <path-to>/connector-1.0.0b1-py3-none-any.whl



# Uninstall

az extension remove --name connector

```



Verify:



```bash

az extension show --name connector --query "{name:name, version:version, preview:preview}" -o table

az connector --help

```



---



## Concepts



| Concept | What it is |

|---|---|

| **Connector Namespace** | Top-level `Microsoft.Web/connectorGateways` resource. Owns API connections, MCP connectors, triggers, and authentication keys. |

| **Connection** | A configured managed-connector instance (e.g. Office 365, SQL). Holds OAuth credentials and supports per-principal access policies. |

| **MCP Connector** | Exposes a connector's operations as **Model Context Protocol** tools that can be served to AI agents. Has its own access policies. |

| **Access Policy** | Authorizes one Entra ID principal (user or group) against a Connection or MCP Connector. |

| **Trigger** | Webhook-style event source (e.g. "new email arrived") that calls a callback URL. |

| **API Key** | Time-bound, scoped runtime credential used by clients to reach the gateway's MCP endpoint. Issued by `list-api-key`. |

| **Access Key** | Static control-plane credential for ARM-level admin access. Rotated via `regenerate-access-key`. |



---



## Quick reference



```

az connector                                  # Manage Connector Namespaces.

├─ create / show / list / update / delete

├─ list-api-key                               # Mint a runtime API key

├─ regenerate-access-key                      # Rotate control-plane key

├─ identity ──── assign / remove / show       # Managed identity for the namespace

├─ connection ───── create / show / list / update / delete

│  ├─ list-consent-links                      # Step 1 of OAuth consent

│  ├─ confirm-consent-code                    # Step 2 of OAuth consent

│  ├─ list-connection-keys                    # Read stored connection keys

│  ├─ invoke                                  # Forward an HTTP request via the connection

│  └─ access-policy ─ create / show / list / update / delete

├─ mcp-connector ── create / show / list / update / delete

│  └─ access-policy ─ create / show / list / update / delete

├─ trigger ──────── create / show / list / update / delete

│  ├─ run ───────── list / show               # Trigger executions

│  └─ status ────── show                      # Subscription lifecycle status

├─ managed-api ────────────── list / show     # Catalog of managed connectors

├─ managed-hosted-mcp-connector list / show   # Catalog of hosted MCP servers

└─ managed-mcp-operation ──── list            # Catalog of MCP-aware operations

```



Get detailed help for any command:



```bash

az connector mcp-connector create --help

az connector connection access-policy create --help

```



---



## Cookbook recipes



The recipes below assume:



```bash

RG=myRG

NS=myConnectorNamespace

LOC=westus2

TENANT=11111111-1111-1111-1111-111111111111

USER_OID=00000000-0000-0000-0000-000000000000   # the user you'll grant access to

```



### Recipe 1 — Bootstrap: namespace + connection + MCP connector



End-to-end happy path: create a Connector Namespace, add an Office 365

connection, complete consent (see [Recipe 2](#recipe-2--oauth-consent-flow-for-a-connection)),

then expose its operations as MCP tools.



```bash

# 1. Create the namespace

az connector create -g $RG -n $NS --location $LOC



# 2. Add a managed connection to Office 365

az connector connection create -g $RG --namespace $NS -n office365Conn \

    --connector-name office365 --display-name "Office 365"



# 3. (Complete OAuth consent — see Recipe 2)



# 4. Wrap the connection's operations as an MCP connector

az connector mcp-connector create -g $RG --namespace $NS -n office365Mcp \

    --connectors '[{"connectionName":"office365Conn"}]'



# 5. Verify

az connector mcp-connector show -g $RG --namespace $NS -n office365Mcp

```



### Recipe 2 — OAuth consent flow for a connection



After `connection create`, most managed connectors need OAuth consent

before any operation can run. The flow is three commands separated by a

browser step.



```bash

# Step 1: generate a consent URL

az connector connection list-consent-links \

    -g $RG --namespace $NS --connection-name office365Conn \

    --parameters '[{

        "objectId": "'$USER_OID'",

        "tenantId": "'$TENANT'",

        "parameterName": "token",

        "redirectUrl": "https://contoso.example/oauth/callback"

    }]'

# → Response contains a `link` URL. Open it in a browser.



# Step 2 (browser): the user authorizes the app.

# The browser is redirected to `redirectUrl?code=<consentCode>`.

# Copy the `code` query parameter.



# Step 3: exchange the consent code for stored credentials

az connector connection confirm-consent-code \

    -g $RG --namespace $NS --connection-name office365Conn \

    --code <consentCode-from-redirect-url> \

    --object-id $USER_OID \

    --tenant-id $TENANT

```



### Recipe 3 — Grant a teammate access to a connection



By default only the connection owner can use its stored credentials. Add an

access policy to authorize additional users.



```bash

TEAMMATE_OID=22222222-2222-2222-2222-222222222222



az connector connection access-policy create \

    -g $RG --namespace $NS --connection-name office365Conn -n grant-bob \

    --principal '{

        "identity": {"objectId": "'$TEAMMATE_OID'", "tenantId": "'$TENANT'"},

        "type": "ActiveDirectory"

    }'

```



Shorthand (nested key syntax) — no JSON quoting required:



```bash

az connector connection access-policy create \

    -g $RG --namespace $NS --connection-name office365Conn -n grant-bob \

    --principal identity.object-id=$TEAMMATE_OID identity.tenant-id=$TENANT type=ActiveDirectory

```



List + cleanup:



```bash

az connector connection access-policy list  -g $RG --namespace $NS --connection-name office365Conn

az connector connection access-policy delete -g $RG --namespace $NS --connection-name office365Conn -n grant-bob

```



### Recipe 4 — Grant a teammate access to an MCP connector



Similar to Recipe 3 but for an MCP connector. Note the **schema differs** —

MCP access policies use a flat `--principal` plus a separate `--principal-type`

(`User` or `Group`). Provisioning is synchronous.



```bash

az connector mcp-connector access-policy create \

    -g $RG --namespace $NS --mcp-connector-name office365Mcp -n grant-bob \

    --principal '{"objectId":"'$TEAMMATE_OID'","tenantId":"'$TENANT'"}' \

    --principal-type User

```



### Recipe 5 — On-behalf-of-user (OBO) MCP connector



Run all tool calls as the **calling user** (per-user dynamic API Hub

connections). No shared credentials. With OBO, `connectionName` on each

connector entry is optional — the gateway provisions a per-caller

connection automatically.



```bash

az connector mcp-connector create -g $RG --namespace $NS -n obo-mcp \

    --authentication-mode OnBehalfOfUser \

    --connectors '[{"connectorName":"sql"}]'

```



### Recipe 6 — Hosted MCP server (FIC + admin app registration)



The gateway provisions and runs an MCP server container for you. This

requires an entry from the catalog (`managed-hosted-mcp-connector`), an

admin app registration for the federated identity credential (FIC), and a

target downstream resource.



```bash

ADMIN_APP=33333333-3333-3333-3333-333333333333   # client_id of admin app registration



az connector mcp-connector create -g $RG --namespace $NS -n hosted-mcp \

    --kind HostedMcpServer \

    --authentication-mode OnBehalfOfUserWithApp \

    --hosted-mcp-server hosted-mcp-server-id=my-hosted-mcp-id \

    --resource-auth target-resource=https://graph.microsoft.com \

                    admin-app-registration.client-id=$ADMIN_APP

```



Switch `--authentication-mode` to `AppOnly` if you want client-credentials

flow (no user token exchange).



### Recipe 7 — Invoke a connector operation through the gateway



`connection invoke` is a generic authenticated HTTP relay — useful for

debugging connections or calling operations not yet wrapped by an MCP tool.

**Do not set auth headers** in `--request headers={}`; the gateway injects

auth from the stored connection credentials.



```bash

# GET /v1.0/me on the Microsoft Graph connector

az connector connection invoke \

    -g $RG --namespace $NS --connection-name office365Conn \

    --request method=GET path=/v1.0/me



# POST with a JSON body + query parameter

az connector connection invoke \

    -g $RG --namespace $NS --connection-name office365Conn \

    --request '{

        "method":  "POST",

        "path":    "/v1.0/me/sendMail",

        "queries": {"$select": "id"},

        "body":    {"message": {"subject": "Hi"}}

    }'

```



### Recipe 8 — Webhook trigger on new email



Create a trigger that fires on new email and calls back to your endpoint.



```bash

az connector trigger create -g $RG --namespace $NS -n onNewEmail \

    --connection-details '{"connectionName":"office365Conn","connectorName":"office365"}' \

    --operation-name OnNewEmail \

    --notification-details '{"callbackUrl":"https://contoso.example/callbacks/email"}'



# Watch executions

az connector trigger run    list -g $RG --namespace $NS --trigger-name onNewEmail

az connector trigger status show -g $RG --namespace $NS --trigger-name onNewEmail -n primary

```



### Recipe 9 — Mint a runtime API key for clients



`list-api-key` (yes, POST-shaped) issues a **time-bound API key** that

clients use to call the gateway's MCP runtime endpoint. Optionally scope

the key to a single MCP connector.



```bash

# Issue a 90-day primary key scoped to one MCP connector

NOT_AFTER=$(date -u -d '90 days' +'%Y-%m-%dT%H:%M:%SZ')



az connector list-api-key -g $RG --namespace $NS \

    --key-type Primary \

    --not-after $NOT_AFTER \

    --scope '{"mcpServerConfigName":"office365Mcp"}'



# Or a never-expiring key scoped to the whole namespace

az connector list-api-key -g $RG --namespace $NS \

    --key-type Primary --never-expire

```



### Recipe 10 — Browse the managed catalogs



The namespace publishes three read-only catalogs that drive what

`mcp-connector create` accepts.



```bash

# All managed API connectors available for this namespace

az connector managed-api list -g $RG --namespace $NS -o table



# Inspect one

az connector managed-api show -g $RG --namespace $NS -n office365



# Hosted MCP server images (use the ids in `--hosted-mcp-server`)

az connector managed-hosted-mcp-connector list -g $RG --namespace $NS -o table



# MCP-aware operations a managed connector exposes

az connector managed-mcp-operation list -g $RG --namespace $NS

```



---



## API keys vs. access keys



| | API key (`list-api-key`) | Access key (`regenerate-access-key`) |

|---|---|---|

| **Plane** | Data plane | Control plane |

| **Used by** | MCP clients (agents) | ARM/RP admin tooling |

| **Lifetime** | Time-bound (`--not-after`) or `--never-expire` | Static until rotated |

| **Scope** | Whole namespace or a single MCP connector | Whole namespace |

| **How to rotate** | Mint a new one; old one auto-expires | `regenerate-access-key --key-type Primary` (or `Secondary`) |



Rotate the primary access key:



```bash

az connector regenerate-access-key -g $RG --namespace $NS --key-type Primary

```



---



## `--namespace` alias on every command



The URL path parameter is `--connector-namespace-name`. Every command

accepts the shorter `--namespace` alias instead — both refer to the same

Connector Namespace name. The recipes above use `--namespace`; the

generated help text mentions both.



```bash

# These are equivalent

az connector connection list -g $RG --namespace myNS

az connector connection list -g $RG --connector-namespace-name myNS

```



---



## Troubleshooting



### `unrecognized arguments: --namespace`



You're hitting a built-in CLI option-conflict — unlikely with this

extension, but if you see it, fall back to `--connector-namespace-name`.



### `unrecognized value 'ActiveDirectory' from choices '['Group', 'User']'`



You used the `connection access-policy` shape on a `mcp-connector

access-policy`. They differ — see Recipe 4.



### `argument value cannot be blank` on `--tags`



Don't pass `--tags ""` to clear tags. Use `--tags ` (no value at all)

to leave existing tags alone, or pass new key=value pairs to overwrite.



### `Failed to parse '--request' argument: ...`



For `connection invoke`, the `--request` object requires `method`. Use

shorthand `method=GET path=/v1.0/me`, or pass full JSON. Avoid setting

auth headers — they'll be overwritten by the gateway.



### `--hosted-mcp-server-id` not recognized



You probably wrote `--hosted-mcp-server-id` at the top level. It's nested

under `--hosted-mcp-server`: `--hosted-mcp-server hosted-mcp-server-id=<id>`.



### OAuth consent: where does the `code` come from?



It's the `code` query parameter on the URL the user is redirected to after

authorizing. If your redirect URL is `https://contoso.example/cb`, the

browser ends up at `https://contoso.example/cb?code=<longHex>` after

consent — that hex string is what you pass to `confirm-consent-code --code`.



### `connector update` only honors `--tags` and `--api-hub-environment-id`



By design. Other fields are immutable post-create. To change properties,

delete and recreate the namespace.



---



## Reporting issues



File issues at: <https://github.com/Azure/azure-cli-extensions/issues>

and tag the issue body with `Extension: connector`.



.. :changelog:



Release History

===============



1.0.0b1

++++++

* Initial release.
